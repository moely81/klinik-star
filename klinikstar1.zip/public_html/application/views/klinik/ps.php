  <div class="container-fluid">
    <button class="btn btn-sm btn-primary mb-3" data-toggle="modal" data-target="#inputpsModal"><i class="fas fa-plus-circle fa-sm" ></i> Input Pasien Baru</button>
    <div class="table-responsive">
      <table id="dataTable" class="table table-hover table-bordered">
        <thead class="text-center" style="font-size:14px">
         <tr>
          <th>No</th>
          <th>Nama</th>
  		  <th>Alamat</th>
          <th>Aksi</th>
          </tr>
        </thead>
        <tbody style="font-size:14px">
        <?php
  		//$start = $this->uri->segment(4); 
        
        foreach($pasien as $ps) : 
         ?>
         
         <tr>
           <td><?php echo $ps->kode ?></td>
           <td><?php echo $ps->nama ?></td>
  			 <td><?php echo $ps->perush ?></td>
             <td><center><a href="<?= base_url('klinik/ps/detail_ps/') . $ps->kode ;?>" class="badge badge-success">detail</a><a class="badge badge-warning ml-1" data-toggle="modal" 
              data-target="#editpsModal<?php echo $ps->id;?>">edit</a>
              <a onclick="return confirm('apakah anda yakin?')" href="<?= base_url('klinik/ps/hapus/') . $ps->id ;?>" class="badge badge-danger">hapus</a></center></td>
          </tr>

        <?php endforeach ;
        ?>
      </tbody>
    </table>
  </div>
  </div>
  <div class="row">
    <div class="col">
     <!--Tampilkan pagination-->
   <!-- <?php echo $this->pagination->create_links(); ?> 
   </div>
 </div>	
</div>
<!-- Modal input-->
<div class="modal fade" id="inputpsModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
 <div class="modal-dialog" role="document">
  <div class="modal-content">
   <div class="modal-header">
    <h5 class="modal-title" id="exampleModalLabel">Input Pasien Baru</h5>
    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
     <span aria-hidden="true">×</span>
   </button>
 </div>
 <div class="modal-body">
  <form action="<?php echo base_url().'klinik/ps/tambah'; ?>" method="post">
   <fieldset>
    <div class="form-group row">
     <label class="col-sm-3 col-form-label">No RM</label>
     <div class="col-md-5">
      <input name="kode" type="text" id="kode" class="form-control" placeholder="STARxxxx" 
      value="STAR<?php echo sprintf("%04s", $kode)?>" readonly>
    </div>
  </div>
</fieldset>
<div class="form-group row">
 <label class="col-sm-3 col-form-label">Nama</label>
 <div class="col-md-9">
   <input type="text" name="nama" class="form-control" id="inputCity" placeholder="Nama" value="" onkeyup="this.value = this.value.toUpperCase()">
 </div>
</div>
<div class="form-group row">
 <label class="col-sm-3 col-form-label">Jenis Kelamin</label>
 <div class="col-sm-6">
   <select class="custom-select mr-sm-4" id="inlineFormCustomSelect" name="jk">
     <option selected>--Pilih Salah Satu--</option>
     <option value="LAKI-LAKI">LAKI-LAKI</option>
     <option value="PEREMPUAN">PEREMPUAN</option>
   </select>
 </div>
</div>
<div class="form-group row">
 <label for="inputEmail3" class="col-sm-3 col-form-label">Tanggal Lahir</label>
 <div class="col-md-6">
   <input type="date" class="form-control" id="inputCity" placeholder="Nama" name="tgl_lhr" value="">
 </div>
</div>
<div class="form-group row">
 <label for="inputEmail3" class="col-sm-3 col-form-label">Alamat</label>
 <div class="col-sm-9">
   <textarea onkeyup="this.value = this.value.toUpperCase()" type="text" name="perush" class="form-control" id="inputEmail3" placeholder=""></textarea>
 </div>
</div>
<div class="form-group row">
 <label class="col-sm-3 col-form-label">Alergi</label>
 <div class="col-md-9">
   <input type="text" name="posisi" class="form-control" id="inputCity" placeholder="Riwayat Alergi" value="" onkeyup="this.value = this.value.toUpperCase()">
 </div>
</div>

<div class="modal-footer">
 <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
 <button class="btn btn-primary" type="submit" name="submit">Submit</button>
</div>
</form>
</div>
</div>
</div>
</div>
</div>

<!-- Modal ubah-->
<?php
foreach ($pasien as $ps):
?>
<div class="modal fade" id="editpsModal<?php echo $ps->id;?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
 <div class="modal-dialog" role="document">
  <div class="modal-content">
   <div class="modal-header">
    <h5 class="modal-title" id="exampleModalLabel">Edit Data Pasien</h5>
    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
     <span aria-hidden="true">×</span>
   </button>
 </div>
 <div class="modal-body">
  <form action="<?php echo base_url('klinik/ps/edit'); ?>" method="post">
   <fieldset>
    <div class="form-group row">
     <label class="col-sm-3 col-form-label">No RM</label>
     <div class="col-md-5">
    <input name="id" type="hidden" id="id" class="form-control" placeholder="STARxxxx" 
      value="<?php echo $ps->id;?>" readonly>
      <input name="kode" type="text" id="kode" class="form-control" placeholder="STARxxxx" 
      value="<?php echo $ps->kode;?>" readonly>
    </div>
  </div>
</fieldset>
<div class="form-group row">
 <label class="col-sm-3 col-form-label">Nama</label>
 <div class="col-md-9">
   <input type="text" name="nama" class="form-control" id="inputCity" onkeyup="this.value = this.value.toUpperCase()" placeholder="Nama" value="<?php echo $ps->nama;?>">
 </div>
</div>
<div class="form-group row">
 <label class="col-sm-3 col-form-label">Jenis Kelamin</label>
 <div class="col-sm-6">
   <select class="custom-select mr-sm-4" id="inlineFormCustomSelect" name="jk">
     <option selected><?php echo $ps->jk;?></option>
     <option value="LAKI-LAKI">LAKI-LAKI</option>
     <option value="PEREMPUAN">PEREMPUAN</option>
   </select>
 </div>
</div>
<div class="form-group row">
 <label for="inputEmail3" class="col-sm-3 col-form-label">Tanggal Lahir</label>
 <div class="col-md-6">
   <input type="date" class="form-control" id="inputCity" placeholder="Nama" name="tgl_lhr" value="<?php echo $ps->tgl_lhr;?>">
 </div>
</div>
<div class="form-group row">
 <label for="inputEmail3" class="col-sm-3 col-form-label">Alamat</label>
 <div class="col-sm-9">
   <input type="text" name="perush" class="form-control" id="perush" onkeyup="this.value = this.value.toUpperCase()" placeholder="" value="<?php echo $ps->perush;?>">
 </div>
</div>
<div class="form-group row">
 <label class="col-sm-3 col-form-label">Alergi</label>
 <div class="col-md-9">
   <input type="text" name="posisi" class="form-control" id="inputCity" placeholder="" value="<?php echo $ps->posisi;?>" onkeyup="this.value = this.value.toUpperCase()">
 </div>
</div>

<div class="modal-footer">
 <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
 <button class="btn btn-primary" type="submit" name="submit">Update</button>
</div>
</form>
</div>
</div>
</div>
</div>
<?php endforeach;?>
</div>
</div>

<!-- Modal detail-->

<?php
function umurmu ($lahir) {
 $pecah = explode("-", $lahir);
 $tgl = intval($pecah['2']);
 $bln = intval($pecah['1']);
 $thn = $pecah['0'];
 $utahun = date("Y") - $thn;
 $ubulan = date("m") - $bln;
 $uhari = date("j") - $tgl;
 if($uhari < 0){
  $uhari = date("t",mktime(0,0,0,$bln-1,date("m"),date("Y"))) - abs($uhari); $ubulan = $ubulan - 1;
}
if($ubulan < 0){
  $ubulan = 12 - abs($ubulan); $utahun = $utahun - 1;
}
$usia = $utahun.'Th '.$ubulan.'Bl '.$uhari.'Hr';
return $usia;
}


?>
<script>
$('#dataTable').dataTable( {
  "lengthChange": false
} );

</script>