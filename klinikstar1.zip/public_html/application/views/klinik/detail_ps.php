<!-- Begin Page Content 
<div class="row">
  <div class="col-md-8">-->
    <div class="container-fluid">
      
          <!-- Page Heading -->
          <div class="text-center mb-3"><a href="<?php echo base_url('klinik/input_dmr/choose/') .$detail_ps['id'];  ?>" class="btn btn-sm btn-info" >Input Data</a></div>
          

          <div class="">
            <div class="col-md-8">
              <div class="table-responsive">
                <table class="table table-borderless">
                  <thead style="font-size:14px">
                  <tr><td>No Registrasi</td><td>:</td><td><?php echo $detail_ps['kode'];?></td></tr>
                  <tr><td>Nama</td><td>:</td><td><?php echo $detail_ps['nama'];?></td></tr>
                  <tr><td>Jenis Kelamin</td><td>:</td><td><?php echo $detail_ps['jk'];?></td></tr>
                  <tr><td>Umur</td><td>:</td><td><?php echo umurmu($detail_ps['tgl_lhr']);?></td></tr>
                  <tr><td>Alamat</td><td>:</td><td><?php echo $detail_ps['perush'];?></td></tr>
                  <tr><td>Alergi</td><td>:</td><td><?php echo $detail_ps['posisi'];?></td></tr>
                  </thead>
                  <tbody style="font-size:14px">
                </table>
              </div>
            </div>
          </div>
        
      <div class="table-responsive">
 				<table id="table_id" class="table table-bordered">
 					<thead class="text-center" style="font-size:14px;">
 						<tr>
 							<th>Tanggal</th>
 							<th>Diagnosa</th>
 							<th>Therapy</th>
 							<th>Aksi</th>
 						</tr>
 					</thead>
 					<?php foreach($dmr as $r) : ?>
 						<tbody style="font-size:14px">
 							<tr>
 								<td><?php echo $r->tgl ?></td>
 								<td><?php echo $r->diag ?></td>
 								<td><?php echo $r->detail ?></td>
 								<td><center><a href="<?= base_url('klinik/dmr/detail_dmr/') . $r->no_dmr ;?>" class="badge badge-success">Detail</a>
 								<a class="badge badge-warning ml-1" data-toggle="modal" data-target="#editdmrModal<?php echo $r->id;?>">Edit</a>
 								<a href="" class="badge badge-danger">Hapus</a></center></td>
 							</tr>
 						</tbody>
 					<?php endforeach ; ?>
 				</table>
 			</div>

<!-- Modal ubah -->
<?php
foreach ($dmr as $r):
?>
<div class="modal fade" id="editdmrModal<?php echo $r->id;?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
 <div class="modal-dialog" role="document">
  <div class="modal-content">
   <div class="modal-header">
    <h5 class="modal-title" id="exampleModalLabel">Edit DMR</h5>
    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
     <span aria-hidden="true">×</span>
   </button>
 </div>
 <div class="modal-body">
  <form action="<?php echo base_url('klinik/detail_ps/edit'); ?>" method="post">
   <fieldset>
    <div class="form-group row">
     <label class="col-sm-3 col-form-label">No RM</label>
     <div class="col-md-5">
    <input name="id" type="hidden" id="id" class="form-control" placeholder="STARxxxx" 
      value="<?php echo $r->id;?>" readonly>
      <input name="kode" type="text" id="kode" class="form-control" placeholder="STARxxxx" 
      value="<?php echo $r->kode;?>" readonly>
    </div>
  </div>
</fieldset>
<div class="form-group row">
 <label for="inputEmail3" class="col-sm-3 col-form-label">Tgl Periksa</label>
 <div class="col-md-6">
   <input type="date" class="form-control" id="inputCity" placeholder="Nama" name="tgl" value="<?php echo $r->tgl;?>">
 </div>
</div>
<div class="form-group row">
 <label class="col-sm-3 col-form-label">Tensi</label>
 <div class="col-md-4">
   <input type="text" name="accid" class="form-control" id="inputCity" placeholder="Tensi" value="<?php echo $r->accid;?>">
 </div>
</div>
<div class="form-group row">
 <label class="col-sm-3 col-form-label">Anamnesa</label>
 <div class="col-md-9">
   <input type="text" name="ohr" class="form-control" id="inputCity" placeholder="Anamnesa" value="<?php echo $r->ohr;?>">
 </div>
</div>
<div class="form-group row">
 <label class="col-sm-3 col-form-label">Diagnosa</label>
 <div class="col-md-9">
   <input type="text" name="diag" class="form-control" id="inputCity" placeholder="diagnosa" value="<?php echo $r->diag;?>">
 </div>
</div>
<div class="form-group row">
 <label class="col-sm-3 col-form-label">Therapi</label>
 <div class="col-md-9">
   <input type="text" name="detail" class="form-control" id="inputCity" placeholder="therapi" value="<?php echo $r->detail;?>">
 </div>
</div>
<div class="form-group row">
 <label class="col-sm-3 col-form-label">Tarif</label>
 <div class="col-md-9">
   <input type="text" name="invest" class="form-control" id="inputCity" placeholder="Tarif" value="<?php echo $r->invest;?>">
 </div>
</div>
<div class="modal-footer">
 <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
 <button class="btn btn-primary" type="submit" name="submit">Update</button>
</div>
</form>
</div>
</div>
</div>
</div>
<?php endforeach;?>
</div>
</div>


  <!--</div>
</div> -->
<?php
function umurmu ($lahir) {
 $pecah = explode("-", $lahir);
 $tgl = intval($pecah['2']);
 $bln = intval($pecah['1']);
 $thn = $pecah['0'];
 $utahun = date("Y") - $thn;
 $ubulan = date("m") - $bln;
 $uhari = date("j") - $tgl;
 if($uhari < 0){
  $uhari = date("t",mktime(0,0,0,$bln-1,date("m"),date("Y"))) - abs($uhari); $ubulan = $ubulan - 1;
}
if($ubulan < 0){
  $ubulan = 12 - abs($ubulan); $utahun = $utahun - 1;
}
$usia = $utahun.'Th '.$ubulan.'Bl '.$uhari.'Hr';
return $usia;
}
?>
