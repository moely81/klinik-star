// Call the dataTables jQuery plugin
//$(document).ready(function() {
//  $('#example1').DataTable();
//});


$(document).ready(function() {
  $('#dataTable').DataTable( {
  "bPaginate": true,
  "bLengthChange": false,
  "bFilter": true,
  "bInfo": false,
  "bAutoWidth": false,
  dom: 'Bfrtip', // if you remove this line you will see the show entries dropdown
        buttons: [
            'copy', 'csv', 'excel', 'pdf', 'print'
        ]
} );
});